# Basko Restaurant Website
## Full Stack — Frontend + Backend

### Stack
- **Frontend**: Pure HTML/CSS/JS — no framework needed
- **Backend**: Node.js + Express REST API
- **Database**: JSON flat-file (easy to migrate to MongoDB/PostgreSQL)
- **Fonts**: Cormorant Garamond (serif) + Jost (sans)

### Pages
| Page | URL |
|------|-----|
| Main Website | `/` or `/index.html` |
| Admin Dashboard | `/admin.html` |

### API Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/menu` | Get full menu & packages |
| POST | `/api/reservations` | Create a reservation |
| GET | `/api/reservations` | List all reservations (admin) |
| GET | `/api/availability?date=YYYY-MM-DD` | Check time slot availability |
| POST | `/api/contact` | Submit contact form |

### Setup & Run

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start

# 3. Open browser
open http://localhost:3000
open http://localhost:3000/admin.html
```

### Deployment Options
1. **Hostinger / Bluehost** — Upload files, run `npm start`
2. **Railway / Render** — Push to GitHub, auto-deploy
3. **Vercel** — Frontend static + serverless functions
4. **VPS (DigitalOcean)** — Full Node.js server

### WhatsApp Integration (Production)
Replace `submitReservation()` with AiSensy or Interakt API call after booking.

### Payment Integration (Production)
Add Razorpay checkout in `bookPackage()` function:
```js
const rzp = new Razorpay({ key_id: 'YOUR_KEY', amount: price*100, ... });
rzp.open();
```
